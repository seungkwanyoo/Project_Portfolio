package org.zerock.domain;

public class YooMath_Ceil {

	public static void main(String[] args) {
//		double num = (Math.ceil(9 / 10.0));
//		System.out.println(num);
//		int intNum = (int) num;
//		System.out.println(intNum);
		int intNum = (int) (Math.ceil(11 / 10.0));
		System.out.println(intNum);
	}
}

   $(document).ready(function () {
      $("#info").hide();
      $("#button").click(function () {
        $("#info").slideToggle();
      });
    });


    $(document).ready(function () {
      $("#info1").hide();
      $("#button1").click(function () {
        $("#info1").slideToggle();
      });
    });

    $(document).ready(function () {
      $("#info2").hide();
      $("#button2").click(function () {
        $("#info2").slideToggle();
      });
    });

    $(document).ready(function () {
      $("#info3").hide();
      $("#button3").click(function () {
        $("#info3").slideToggle();
      });
    });

    $(document).ready(function () {
      $("#info4").hide();
      $("#button4").click(function () {
        $("#info4").slideToggle();
      });
    });

    $(document).ready(function () {
      $("#info7").hide();
      $("#button7").click(function () {
        $("#info7").slideToggle();
      });
    });


    $(document).ready(function () {
      $("#info8").hide();
      $("#button8").click(function () {
        $("#info8").slideToggle();
      });
    });

    $(document).ready(function () {
      $("#info9").hide();
      $("#button9").click(function () {
        $("#info9").slideToggle();
      });
    });

    $(document).ready(function () {
      $("#info10").hide();
      $("#button10").click(function () {
        $("#info10").slideToggle();
      });
    });

    $(document).ready(function () {
      $("#info11").hide();
      $("#button11").click(function () {
        $("#info11").slideToggle();
      });
    });

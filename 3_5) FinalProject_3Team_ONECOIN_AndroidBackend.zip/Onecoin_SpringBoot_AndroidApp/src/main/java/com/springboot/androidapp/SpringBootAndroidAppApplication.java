package com.springboot.androidapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAndroidAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAndroidAppApplication.class, args);
	}

}
